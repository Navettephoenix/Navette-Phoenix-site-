
import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Navette Phoenix')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Bienvenue sur Navette Phoenix'),
            ElevatedButton(
              onPressed: () => Navigator.pushNamed(context, '/reservation'),
              child: Text('Réserver un transport'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pushNamed(context, '/devis'),
              child: Text('Demander un devis'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pushNamed(context, '/espace-client'),
              child: Text('Espace Client'),
            ),
          ],
        ),
      ),
    );
  }
}
