
import 'package:flutter/material.dart';

class DevisPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Demande de devis')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(decoration: InputDecoration(labelText: 'Nom')),
            TextField(decoration: InputDecoration(labelText: 'Téléphone')),
            TextField(decoration: InputDecoration(labelText: 'Email')),
            TextField(decoration: InputDecoration(labelText: 'Départ')),
            TextField(decoration: InputDecoration(labelText: 'Destination')),
            TextField(decoration: InputDecoration(labelText: 'Date & Heure')),
            TextField(decoration: InputDecoration(labelText: 'Commentaire')),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => Navigator.pushNamed(context, '/'),
              child: Text('Envoyer la demande'),
            ),
          ],
        ),
      ),
    );
  }
}
