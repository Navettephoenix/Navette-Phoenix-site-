
import 'package:flutter/material.dart';

class ConfirmationPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Confirmation')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Votre réservation a bien été enregistrée.'),
            Text('Le paiement s’effectuera dans le véhicule.'),
            ElevatedButton(
              onPressed: () => Navigator.pushNamed(context, '/'),
              child: Text('Retour à l’accueil'),
            ),
          ],
        ),
      ),
    );
  }
}
