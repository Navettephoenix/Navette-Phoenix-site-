
import 'package:flutter/material.dart';

class ReservationPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Réservation')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(decoration: InputDecoration(labelText: 'Départ')),
            TextField(decoration: InputDecoration(labelText: 'Destination')),
            TextField(decoration: InputDecoration(labelText: 'Date & Heure')),
            TextField(decoration: InputDecoration(labelText: 'Nombre de personnes')),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => Navigator.pushNamed(context, '/confirmation'),
              child: Text('Confirmer la réservation'),
            ),
          ],
        ),
      ),
    );
  }
}
