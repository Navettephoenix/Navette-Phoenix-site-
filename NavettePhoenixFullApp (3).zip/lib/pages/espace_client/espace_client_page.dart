
import 'package:flutter/material.dart';

class EspaceClientPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Espace Client')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Historique de vos réservations'),
            // Placeholder content
            ListTile(title: Text('08/08/2025 - La Loupe > Nogent-le-Rotrou')),
            ListTile(title: Text('10/08/2025 - Senonches > Aéroport CDG')),
            ElevatedButton(
              onPressed: () => Navigator.pushNamed(context, '/'),
              child: Text('Retour à l’accueil'),
            ),
          ],
        ),
      ),
    );
  }
}
