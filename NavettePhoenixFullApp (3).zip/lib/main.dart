
import 'package:flutter/material.dart';
import 'pages/home/home_page.dart';
import 'pages/reservation/reservation_page.dart';
import 'pages/confirmation/confirmation_page.dart';
import 'pages/devis/devis_page.dart';
import 'pages/espace_client/espace_client_page.dart';

void main() => runApp(NavettePhoenixApp());

class NavettePhoenixApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Navette Phoenix',
      debugShowCheckedModeBanner: false,
      initialRoute: '/',
      routes: {
        '/': (context) => HomePage(),
        '/reservation': (context) => ReservationPage(),
        '/confirmation': (context) => ConfirmationPage(),
        '/devis': (context) => DevisPage(),
        '/espace-client': (context) => EspaceClientPage(),
      },
    );
  }
}
